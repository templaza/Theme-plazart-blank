<?php
/**
 * @package Plazart
 */
/*
Plugin Name: Plazart
Plugin URI: http://templaza.com/
Description: This is plugin for Templaza. This plugin allows you to create post types, taxonomies and Visual Composer's shortcodes
Version: 1.0.0
Author: Templaza
Author URI: http://template.com/
License: GPLv2 or later
*/


/**
 * This is the TZPlazart loader class.
 *
 * @package   TZPlazart
 * @author    templaza (http:://templaza.com)
 * @copyright Copyright (c) 2014, Templaza
 */

if ( !class_exists('TZ_Plazart') ):

    class TZ_Plazart{

        /*
         * This method loads other methods of the class.
         */
        public function __construct(){
            /* load languages */
            $this -> load_languages();

            /*load all plazart*/
            $this -> load_plazart();

            /*load all script*/
            $this -> load_script();
        }

        /*
         * Load the languages before everything else.
         */
        public function load_languages(){
            add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
        }

        /*
         * Load the text domain.
         */
        public function load_textdomain(){

            load_plugin_textdomain( tz_plazart, false, plugin_dir_url( __FILE__ ) . '/languages' );
        }

        /*
         * Load script
         */
        public function load_script(){
            if( is_admin() ){
                add_action('admin_enqueue_scripts', array( $this,'admin_scripts') );
            }
        }

        /*
         * Load TZPlazart on the 'after_setup_theme' action. Then filters will
         */
        public function load_plazart(){

            $this -> constants();

            $this -> admin_includes();


        }

        /**
         * Constants
         */
        private function constants(){

            define('tz_plazart', 'tz-plazart');

            define('PLUGIN_PREFIX', 'plazart');

            define('PLUGIN_PATH', plugin_dir_url( __FILE__ ));

            define('PLUGIN_SERVER_PATH',dirname( __FILE__ ) );
        }

        /*
         * Require file
         */
        public function  admin_includes(){
            require_once PLUGIN_SERVER_PATH.'/admin/admin-init.php';
        }

        /*
        * Require file
        */
        public function  admin_scripts(){
            global $pagenow;
            if ('post-new.php' == $pagenow || 'post.php' == $pagenow) :
                wp_enqueue_style('thickbox');
                wp_enqueue_script('media-upload');
                wp_enqueue_script('thickbox');

                // load css
                wp_enqueue_style('jquery.fancybox', PLUGIN_PATH. 'assets/css/jquery.fancybox.css');
                wp_enqueue_style('shortocde_admin', PLUGIN_PATH. 'assets/css/shortocde_admin.css');

                // load js
                wp_register_script('jquery.fancybox_js', PLUGIN_PATH .'assets/js/jquery.fancybox.js', false, false, $in_footer=true);
                wp_enqueue_script('jquery.fancybox_js')  ;
            endif;
        }


    }
    $oj_plazart = new TZ_Plazart();

endif;

?>