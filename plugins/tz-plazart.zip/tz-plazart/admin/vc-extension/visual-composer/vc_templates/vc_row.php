<?php
$output = $el_class = $bg_image = $bg_color = $bg_image_repeat = $font_color = $padding = $margin_bottom = $css = $style_width ='';
extract(shortcode_atts(array(
    'el_class'        => '',
    'bg_image'        => '',
    'bg_color'        => '',
    'bg_image_repeat' => '',
    'font_color'      => '',
    'padding'         => '',
    'margin_bottom'   => '',
    'style_width'   => '',
    'background_parallax'   => '',
    'overlay_parallax'   => '',
    'css' => ''
), $atts));

// wp_enqueue_style( 'js_composer_front' );
wp_enqueue_script( 'wpb_composer_front_js' );
// wp_enqueue_style('js_composer_custom_css');
$class_parallax = '';
if ( $background_parallax == 'yes' ):
    $class_parallax = "parallax ";
endif;


$el_class = $this->getExtraClass($el_class);

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'vc_row wpb_row '.$class_parallax. ( $this->settings('base')==='vc_row_inner' ? 'vc_inner ' : '' ) . get_row_css_class() . $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );


$style = $this->buildStyle($bg_image, $bg_color, $bg_image_repeat, $font_color, $padding, $margin_bottom);


$output .= '<div class="'.$css_class.'"'.$style.'>';
    if ( $background_parallax == 'yes' ):
        $output .= '<div class="overlay_parallax" style="background-color:'.$overlay_parallax.'"></div>';
    endif;
    if ( $style_width == 'boxed' ):
        $output .= '<div class="container"><div class="row">';
        $output .= wpb_js_remove_wpautop($content);
        $output .= '</div></div>';
    else:
        $output .= '<div class="nocontainer">';
        $output .= wpb_js_remove_wpautop($content);
        $output .= '</div>';

    endif;
$output .= '</div>'.$this->endBlockComment('row');
echo $output;