<?php

/*=====================================
 * Visual Composer
 =====================================*/



if ( class_exists('WPBakeryVisualComposerAbstract') ):
    function tzplazart_includevisual(){
        $dir_vc = dirname( __FILE__ );

        require_once $dir_vc . '/visual-composer/custom_vc.php';
        // VC Templates
        $vc_templates_dir = $dir_vc . '/visual-composer/vc_templates/';
        vc_set_shortcodes_templates_dir($vc_templates_dir);

//        require_once $dir_vc . '/vc_your/your-header.php';
//        require_once $dir_vc . '/visual-composer/vc-your-header.php';

    }

    add_action('init', 'tzplazart_includevisual', 20);
endif;

?>
